﻿using System.Data.SqlTypes;

namespace OnlineTrading.Repository.Interfaces.Shop
{
    public class ShopFilter
    {
        public SqlString? Name { get; set; }
    }
}