﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineTrading.Service.DTOs.Shop
{
    public class ShopInfo
    {
        public int ShopId { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
    }
}
