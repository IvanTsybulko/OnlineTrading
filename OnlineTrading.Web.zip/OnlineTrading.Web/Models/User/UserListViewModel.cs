﻿namespace OnlineTrading.Web.Models.User
{
    public class UserListViewModel
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Role { get; set; }
        
    }
}
